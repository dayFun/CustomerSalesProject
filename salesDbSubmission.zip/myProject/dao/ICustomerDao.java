package myProject.dao;

import java.util.List;

import myProject.model.Customer;

public interface ICustomerDao {

	public List<Customer> getAllCustomers();
}
