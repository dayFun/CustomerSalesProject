package myProject.listeners;

public interface IPreferencesListener {

    public void preferencesSet(String url, String user, String password, String port);
}
